"""
角色管理
"""
from django.shortcuts import render,redirect,HttpResponse
from  django.urls import  reverse
from  rbac import models

#引入角色管理的表单
from  rbac.forms.role import RoleModelForm

def role_list(request):
    ''''
    角色列表获取视图
    :param  request
    :return:
    '''

    #从数据库取出所有的角色信息
    role_queryset=models.Role.objects.all()
    return render(request,'rbac/role_list.html',{'roles':role_queryset})

def role_add(request):
    '''
    添加角色
    :param request:
    :return:
    '''
    if request.method== 'GET':
        form =RoleModelForm()
        return render(request,'rbac/role_add.html',{'form':form})

    #跳转页面后对信息的验证
    form=RoleModelForm(data=request.POST)
    #如果验证通过
    if form.is_valid():
        form.save()
        #添加成功，返回到角色列表
        return redirect(reverse('rbac:role_list'))
    #如果验证失败，错误信息也是把保存在form中,显示在html框
    return render(request,'rbac/role_add.html',{'form':form})

def role_edit(request,pk):
    ''''
    编辑角色
    :param request:
    :param pk:要修改的角色ID
    :return
    '''
    #拿到当前的角色
    obj=models.Role.objects.filter(id=pk).first()
    #如果角色不存在
    if not obj:
        return HttpResponse('角色不存在')
    #角色存在
    if request.method=='GET':
        #默认赋值，input框里面
        form=RoleModelForm(instance=obj)
        return render(request,'rbac/change.html',{'form':form})

    #表单里面修改之后的数据传给过来
    form=RoleModelForm(instance=obj,data=request.POST)
    #如果验证通过,保存数据
    if form.is_valid():
        form.save()
        #更新完数据库返回角色列表
        return redirect(reverse('rbac:role_list'))
    #如果不成功，把错误信息返回到修改的页面进行展示
    return render(request, 'rbac/change.html', {'form': form})

def role_del(request,pk):
    """
    删除角色
    :param request:
    :param pk:
    :return:
    """
    #反向跳转，起始地址,
    origin_url=reverse('rbac:role_list')
    if request.method=='GET':
        return  render((request),'rbac/delete.html',{'cancel': origin_url})
    #执行删除当前主键的角色
    models.Role.objects.filter(id=pk).delete()
    #删除成功后跳转回角色列表
    return redirect(origin_url)