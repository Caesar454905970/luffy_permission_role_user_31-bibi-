"""
用户管理
"""
from django.shortcuts import render, redirect, HttpResponse
from django.urls import reverse
from rbac import models

#引入用户管理的表单
from  rbac.forms.user import UserModelForm,UpdateUserModelForm,ResetPasswordUserModelForm

def user_list(request):
    ''''
    用户列表获取视图
    :param  request
    :return:
    '''

    #从数据库取出所有的角色信息
    user_queryset=models.UserInfo.objects.all()
    return render(request,'rbac/user_list.html',{'users':user_queryset})

def user_add(request):
    '''
    添加用户
    :param request:
    :return:
    '''
    if request.method== 'GET':
        form =UserModelForm()
        #接收到请求跳转到添加用户页面
        return render(request,'rbac/change.html',{'form':form})

    #跳转页面后对信息的验证
    form = UserModelForm(data=request.POST)
    #如果验证通过
    if form.is_valid():
        form.save()
        #添加成功，返回到角色列表
        return redirect(reverse('rbac:user_list'))
    #如果验证失败，错误信息也是把保存在form中,显示在html框
    return render(request,'rbac/change.html',{'form':form})

def user_edit(request,pk):
    ''''
    编辑用户
    :param request:
    :param pk:要修改的角色ID
    :return
    '''
    #拿到当前的角色
    obj=models.UserInfo.objects.filter(id=pk).first()
    #如果角色不存在
    if not obj:
        return HttpResponse('用户不存在')
    #角色存在
    if request.method=='GET':
        #默认赋值，input框里面
        form=UpdateUserModelForm(instance=obj)
        return render(request,'rbac/change.html',{'form':form})

    #表单里面修改之后的数据传给过来
    form = UpdateUserModelForm(instance=obj,data=request.POST)
    #如果验证通过,保存数据
    if form.is_valid():
        form.save()
        #更新完数据库返回角色列表
        return redirect(reverse('rbac:user_list'))
    #如果不成功，把错误信息返回到修改的页面进行展示
    return render(request, 'rbac/change.html', {'form': form})

def user_reset_pwd(request,pk):
    """
    重置密码
    :param request:
    :param pk:
    :return:
    """
    #拿到当前的角色
    obj = models.UserInfo.objects.filter(id=pk).first()
    #如果角色不存在
    if not obj:
        return HttpResponse('用户不存在')
    #角色存在
    if request.method == 'GET':
        #默认赋值，input框里面(重置密码2个框里面都不要默认值）
        form = ResetPasswordUserModelForm()
        return render(request, 'rbac/change.html',{'form':form})
    #表单里面修改之后的数据传给过来
    form=ResetPasswordUserModelForm(instance=obj,data=request.POST)
    #如果验证通过,保存数据
    if form.is_valid():
        form.save()
        #更新完数据库返回角色列表
        return redirect(reverse('rbac:user_list'))
    #如果不成功，把错误信息返回到修改的页面进行展示
    return render(request, 'rbac/change.html', {'form': form})


def user_del(request,pk):
    """
    删除用户
    :param request:
    :param pk:
    :return:
    """
    #反向跳转，起始地址,
    origin_url=reverse('rbac:user_list')
    if request.method=='GET':
        return  render((request),'rbac/delete.html',{'cancel': origin_url})
    #执行删除当前主键的用户
    models.UserInfo.objects.filter(id=pk).delete()
    #删除成功后跳转回用户列表
    return redirect(origin_url)