from django.conf.urls import url,include
from django.contrib import admin
from rbac.views import role
from rbac.views import user

urlpatterns = [
    #显示角色列表:因为视图的html前面多加了一个rbac/,所以访问地址/rbac/role/list/
    url(r'^role/list/$', role.role_list,name='role_list'), #rbac:role_list
    #添加角色列表
    #name用于页面上按钮的权限的控制，反向生成跳转地址
    url(r'^role/add/$', role.role_add,name='role_add'),#rbac:role_add
    # 编辑角色列表,接受当前编辑角色的id
    url(r'^role/edit/(?P<pk>\d+)/$', role.role_edit, name='role_edit'),  # rbac:role_edit
    # 删除角色列表,接受当前编辑角色的id
    url(r'^role/del/(?P<pk>\d+)/$', role.role_del, name='role_del'),  # rbac:role_del

    # 显示用户列表:因为视图的html前面多加了一个rbac/,所以访问地址/rbac/user/list/
    url(r'^user/list/$', user.user_list, name='user_list'),  # rbac:user_list
    # 添加用户列表
    # name用于页面上按钮的权限的控制，反向生成跳转地址
    url(r'^user/add/$', user.user_add, name='user_add'),  # rbac:user_add
    # 编辑用户列表,接受当前编辑用户的id
    url(r'^user/edit/(?P<pk>\d+)/$', user.user_edit, name='user_edit'),  # rbac:user_edit
    # 删除用户列表,接受当前编辑用户的id
    url(r'^user/del/(?P<pk>\d+)/$', user.user_del, name='user_del'),  # rbac:user_del
    # 重置用户名密码
    url(r'^user/reset/password/(?P<pk>\d+)/$', user.user_reset_pwd, name='user_reset_pwd'),  # rbac:user_reset_pwd
]