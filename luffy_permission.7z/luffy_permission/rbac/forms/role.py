
from django import forms
from  rbac import models

class RoleModelForm(forms.ModelForm):
    #对角色表里面的字段进行操作
    class Meta:
        model=models.Role
        # fields='__all__'
        fields=['title',]
        #给html中title字段的输入框加一个class属性
        widgets={
            'title':forms.TextInput(attrs={'class':'form-control'})
        }
