#抛出报错
from  django.core.exceptions import  ValidationError
from django import forms
from  rbac import models
#增加用户
class UserModelForm(forms.ModelForm):
    #表单额外的字段，不在数据库中
    confirm_password=forms.CharField(label='确认密码')
    #对角色表里面的字段进行操作
    class Meta:
        #调用数据库
        model=models.UserInfo
        # fields='__all__'
        #3个是数据库，一个是额外自己的
        fields=['name','email','password','confirm_password']
    #初始化方法
    def __init__(self,*args,**kwargs):
        super(UserModelForm, self).__init__(*args,**kwargs)
        #为fields中的4个字段加一个样式
        for name,field in self.fields.items():
            field.widget.attrs['class']='form-control'


    #钩子函数，对用户提交的字段进行校验
    def clean_confirm_password(self):
        """
        检测密码是否一致的钩子函数
        :return:
        """
        #用户输入的第一个密码，数据库中字段的密码
        password=self.cleaned_data['password']
        #form中自定义的密码
        confirm_password = self.cleaned_data['confirm_password']
        #两次输入不一致
        if password!=confirm_password:
            #抛出异常
            raise ValidationError('两次密码不一致')

        #没有异常，返回确认密码
        return confirm_password


#编辑用户(不包括展示密码）
class UpdateUserModelForm(forms.ModelForm):
    #对角色表里面的字段进行操作
    class Meta:
        #调用数据库
        model=models.UserInfo
        # fields='__all__'
        #2个是数据库
        fields=['name','email',]
    #初始化方法
    def __init__(self,*args,**kwargs):
        super(UpdateUserModelForm, self).__init__(*args,**kwargs)
        #为fields中的4个字段加一个样式
        for name,field in self.fields.items():
            field.widget.attrs['class']='form-control'

#重置用户密码
class ResetPasswordUserModelForm(forms.ModelForm):
    #表单额外的字段，不在数据库中
    confirm_password=forms.CharField(label='确认密码')
    #对角色表里面的字段进行操作
    class Meta:
        #调用数据库
        model=models.UserInfo
        # fields='__all__'
        #1个是数据库,一个是自定义的字段
        fields=['password','confirm_password']
    #初始化方法
    def __init__(self,*args,**kwargs):
        super(ResetPasswordUserModelForm, self).__init__(*args,**kwargs)
        #为fields中的4个字段加一个样式
        for name,field in self.fields.items():
            field.widget.attrs['class']='form-control'
    #钩子函数，对用户提交的字段进行校验
    def clean_confirm_password(self):
        """
        检测密码是否一致的钩子函数
        :return:
        """
        #用户输入的第一个密码，数据库中字段的密码
        password=self.cleaned_data['password']
        #form中自定义的密码
        confirm_password = self.cleaned_data['confirm_password']
        #两次输入不一致
        if password!=confirm_password:
            #抛出异常
            raise ValidationError('两次密码不一致')

        #没有异常，返回确认密码
        return confirm_password
